from django.apps import AppConfig


class UniDepartSiteConfig(AppConfig):
    name = 'uni_depart_site'
