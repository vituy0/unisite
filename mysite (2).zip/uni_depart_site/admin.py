from django.contrib import admin

# Register your models here.


# @admin.register(Test)
# class TestAdmin(admin.ModelAdmin):
#     list_display = ('id', 'title', 'url')